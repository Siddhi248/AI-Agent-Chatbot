# NEXUS AI 2.0 — Advanced Multi-Agent Assistant

A full-stack FastAPI application with a LangGraph orchestration workflow, eight specialist agents, user authentication, Chroma vector retrieval and a responsive professional dashboard.

## Architecture

- **FastAPI** backend and JSON API
- **LangGraph** workflow: planner → parallel specialist agents → synthesis
- **OpenAI chat model** for specialist reasoning and cross-agent synthesis
- **ChromaDB** persistent vector store with user-scoped metadata filters
- **OpenAI embeddings** for semantic document retrieval
- **SQLite** persistence for accounts, sessions, messages, document metadata and feedback
- **JWT access tokens** and Argon2 password hashing
- Responsive HTML/CSS/JS frontend with voice input/output via browser APIs

## Setup

Requires Python 3.10+.

```bash
python -m venv .venv

# Windows
.venv\Scripts\activate

# macOS/Linux
source .venv/bin/activate

pip install -r requirements.txt
```

Copy `.env.example` to `.env`. Generate a strong secret key and configure your OpenAI API key:

```env
SECRET_KEY=use-a-long-random-secret
OPENAI_API_KEY=your-key
OPENAI_MODEL=gpt-4o-mini
OPENAI_EMBEDDING_MODEL=text-embedding-3-small
```

Do not put secrets in frontend code or commit `.env` to source control.

Run:

```bash
uvicorn app.main:app --reload
```

Open http://127.0.0.1:8000

The first registered account is assigned the admin role on a fresh database. You can also set `ADMIN_EMAIL` to designate an admin email. For a real public deployment, remove the first-user-admin bootstrap and create admins through a controlled administrative process.

## How agent collaboration works

1. The planner scores the user message against domain keywords.
2. It selects up to three relevant agents (or a manually selected agent).
3. LangGraph dispatches specialist nodes concurrently using `Send`.
4. Each specialist independently retrieves relevant user-owned document chunks from Chroma.
5. Specialists generate domain-focused results.
6. The synthesis node merges results into one response and returns retrieved source labels.

This is a genuine parallel LangGraph workflow, not just a frontend agent selector.

## RAG workflow

- PDF/TXT/Markdown extraction
- Text chunking with overlap
- OpenAI embedding generation
- Persistent Chroma storage
- User-scoped vector filtering
- Semantic top-k retrieval
- Retrieved passages supplied to specialist prompts
- Source filenames displayed with the answer

Scanned PDFs require OCR and are not OCR-processed in this starter.

## Authentication and data isolation

- Email/password registration and login
- Argon2 password hashing
- Signed JWT access tokens
- Protected chat, history, document and admin endpoints
- Session ownership checks
- User-scoped document metadata and vector retrieval

For production, add refresh-token rotation/revocation, email verification, password reset, CSRF protections where cookie auth is used, rate limits, audit logs, stronger account recovery, encrypted backups and security monitoring.

## Safety boundaries

Healthcare, legal and finance specialists have domain-specific system prompts that restrict them to general information and encourage qualified professional review. This is not a regulated professional service or emergency response system. Add a reviewed policy layer, region-specific verified sources, human escalation workflows and ongoing red-team evaluations before public use.

## Important production gaps

This is an advanced runnable foundation, not a fully production-hardened enterprise deployment. Before launching publicly:

1. Add automated tests, migrations and structured observability.
2. Add refresh-token rotation, revocation, email verification and account recovery.
3. Add rate limiting, abuse prevention, upload malware scanning and file retention controls.
4. Add OCR for scanned PDFs, reranking, hybrid search, source-level page references and retrieval evaluation.
5. Replace keyword-only planning with an LLM-based structured planner plus policy validation.
6. Add a real human escalation/ticket provider and emergency workflows.
7. Add a moderation and prompt-injection defense layer for user documents and retrieved text.
8. Add HTTPS, secure deployment secrets, backups, monitoring and privacy/consent controls.
9. Review current model/provider terms, regional laws and data-processing requirements before processing sensitive data.

## API overview

- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET /api/auth/me`
- `GET /api/agents`
- `POST /api/chat`
- `GET /api/sessions`
- `GET /api/history/{session_id}`
- `DELETE /api/sessions/{session_id}`
- `POST /api/upload`
- `GET /api/documents`
- `DELETE /api/documents/{document_id}`
- `POST /api/feedback`
- `GET /api/admin/stats` (admin only)
- `GET /api/health`

Interactive API docs: http://127.0.0.1:8000/docs


## Repository documentation

- `DEPLOYMENT.md` — Docker deployment steps and production checklist
- `SECURITY.md` — security reporting and deployment considerations
- `CONTRIBUTING.md` — contribution workflow
- `.github/workflows/ci.yml` — basic Python syntax CI check

## GitHub publishing

Create an empty GitHub repository, then from this project folder:

```bash
git init
git add .
git commit -m "Initial NEXUS AI 2.0 release"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

Do not upload `.env`, API keys, database files or user documents.
