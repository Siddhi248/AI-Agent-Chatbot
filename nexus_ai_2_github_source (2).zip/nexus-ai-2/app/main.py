from __future__ import annotations
import os, uuid, json, io
from datetime import datetime, timezone
from pathlib import Path
from fastapi import FastAPI, UploadFile, File, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel, EmailStr, Field
from dotenv import load_dotenv
load_dotenv()

from app.config import get_settings
from app.db import connect, init_db
from app.security import hash_password, verify_password, create_token, current_user, require_admin
from app.agents.catalog import AGENTS
from app.agents.graph import run_graph
from app.rag import add_document, delete_document

settings = get_settings()
app = FastAPI(title=settings.app_name, version="2.0.0")
app.add_middleware(CORSMiddleware, allow_origins=settings.origins, allow_credentials=True,
                   allow_methods=["GET","POST","DELETE"], allow_headers=["*"])
init_db()

def now(): return datetime.now(timezone.utc).isoformat()

class RegisterBody(BaseModel):
    name: str = Field(min_length=2, max_length=80)
    email: EmailStr
    password: str = Field(min_length=10, max_length=128)

class LoginBody(BaseModel):
    email: EmailStr
    password: str

class ChatBody(BaseModel):
    message: str = Field(min_length=1, max_length=12000)
    session_id: str | None = None
    agent: str = "auto"
    language: str = "Auto"

class FeedbackBody(BaseModel):
    session_id: str
    rating: int = Field(ge=1, le=5)
    comment: str = Field(default="", max_length=1000)

@app.on_event("startup")
def startup():
    # First registered account is admin for a fresh local installation.
    with connect() as con:
        count = con.execute("SELECT COUNT(*) n FROM users").fetchone()["n"]
        if count == 0:
            print("NEXUS AI: first registered account will receive admin role.")

@app.get("/")
def index():
    return FileResponse(Path(__file__).parent / "static" / "index.html")

@app.get("/api/health")
def health():
    return {"ok":True,"app":settings.app_name,"llm_configured":bool(settings.openai_api_key)}

@app.get("/api/agents")
def list_agents():
    return AGENTS

@app.post("/api/auth/register")
def register(body: RegisterBody):
    email = body.email.lower()
    with connect() as con:
        exists = con.execute("SELECT id FROM users WHERE email=?", (email,)).fetchone()
        if exists: raise HTTPException(409, "An account with this email already exists")
        count = con.execute("SELECT COUNT(*) n FROM users").fetchone()["n"]
        role = "admin" if count == 0 or email == settings.admin_email.lower() else "user"
        user_id = str(uuid.uuid4())
        con.execute("INSERT INTO users VALUES(?,?,?,?,?,?)",
                    (user_id,email,body.name.strip(),hash_password(body.password),role,now()))
        user = dict(con.execute("SELECT id,email,name,role,created_at FROM users WHERE id=?",(user_id,)).fetchone())
    return {"user":user,"access_token":create_token(user),"refresh_token":create_token(user,"refresh"),"token_type":"bearer"}

@app.post("/api/auth/login")
def login(body: LoginBody):
    with connect() as con:
        row = con.execute("SELECT * FROM users WHERE email=?", (body.email.lower(),)).fetchone()
    if not row or not verify_password(body.password,row["password_hash"]):
        raise HTTPException(401,"Incorrect email or password")
    user = {k:row[k] for k in ["id","email","name","role","created_at"]}
    return {"user":user,"access_token":create_token(user),"refresh_token":create_token(user,"refresh"),"token_type":"bearer"}

@app.get("/api/auth/me")
def me(user=Depends(current_user)):
    return user

@app.post("/api/chat")
def chat(body: ChatBody, user=Depends(current_user)):
    if body.agent != "auto" and body.agent not in AGENTS:
        raise HTTPException(400,"Unknown agent")
    session_id = body.session_id or str(uuid.uuid4())
    with connect() as con:
        row = con.execute("SELECT id FROM sessions WHERE id=? AND user_id=?",(session_id,user["id"])).fetchone()
        if body.session_id and not row: raise HTTPException(404,"Conversation not found")
        if not row:
            con.execute("INSERT INTO sessions VALUES(?,?,?,?,?)",
                        (session_id,user["id"],body.message[:72],now(),now()))
        con.execute("INSERT INTO messages(session_id,user_id,role,content,agent,sources,created_at) VALUES(?,?,?,?,?,?,?)",
                    (session_id,user["id"],"user",body.message,body.agent,"[]",now()))
        recent = con.execute("SELECT role,content FROM messages WHERE session_id=? ORDER BY id DESC LIMIT 8",(session_id,)).fetchall()
    history = "\n".join(f"{r['role']}: {r['content'][:700]}" for r in reversed(recent[:-1]))
    try:
        result = run_graph(user_id=user["id"],message=body.message,requested_agent=body.agent,
                           language=body.language,history=history)
    except Exception as exc:
        # Do not expose internal exceptions or secrets to clients.
        print(f"Agent graph error: {type(exc).__name__}: {exc}")
        raise HTTPException(503,"The AI workflow is temporarily unavailable. Check API configuration and server logs.")
    selected = result.get("selected_agents",[])
    sources = result.get("sources",[])
    answer = result.get("final_answer","No response generated.")
    with connect() as con:
        con.execute("INSERT INTO messages(session_id,user_id,role,content,agent,sources,created_at) VALUES(?,?,?,?,?,?,?)",
                    (session_id,user["id"],"assistant",answer,",".join(selected),json.dumps(sources),now()))
        con.execute("UPDATE sessions SET updated_at=? WHERE id=?",(now(),session_id))
    return {"session_id":session_id,"agents":selected,"agent_names":[AGENTS[a]["name"] for a in selected],
            "answer":answer,"sources":[{"filename":s["filename"],"excerpt":s["text"][:260]} for s in sources],
            "mode":"live" if settings.openai_api_key else "demo"}

@app.get("/api/sessions")
def sessions(user=Depends(current_user)):
    with connect() as con:
        rows=con.execute("SELECT id,title,created_at,updated_at FROM sessions WHERE user_id=? ORDER BY updated_at DESC LIMIT 50",(user["id"],)).fetchall()
    return [dict(r) for r in rows]

@app.get("/api/history/{session_id}")
def history(session_id: str,user=Depends(current_user)):
    with connect() as con:
        s=con.execute("SELECT * FROM sessions WHERE id=? AND user_id=?",(session_id,user["id"])).fetchone()
        if not s: raise HTTPException(404,"Conversation not found")
        rows=con.execute("SELECT role,content,agent,sources,created_at FROM messages WHERE session_id=? ORDER BY id",(session_id,)).fetchall()
    return {"session":dict(s),"messages":[{**dict(r),"sources":json.loads(r["sources"] or "[]")} for r in rows]}

@app.delete("/api/sessions/{session_id}")
def delete_session(session_id: str,user=Depends(current_user)):
    with connect() as con:
        cur=con.execute("DELETE FROM sessions WHERE id=? AND user_id=?",(session_id,user["id"]))
        if cur.rowcount == 0: raise HTTPException(404,"Conversation not found")
    return {"deleted":True}

@app.post("/api/upload")
async def upload(file: UploadFile=File(...),user=Depends(current_user)):
    filename=Path(file.filename or "upload").name
    suffix=Path(filename).suffix.lower()
    if suffix not in [".pdf",".txt",".md"]: raise HTTPException(400,"Supported files: PDF, TXT, Markdown")
    data=await file.read()
    if len(data)>settings.max_upload_mb*1024*1024: raise HTTPException(413,f"File exceeds {settings.max_upload_mb} MB")
    try:
        if suffix==".pdf":
            from pypdf import PdfReader
            reader=PdfReader(io.BytesIO(data))
            content="\n".join(page.extract_text() or "" for page in reader.pages)
        else: content=data.decode("utf-8",errors="replace")
    except Exception: raise HTTPException(400,"Could not extract readable text from this file")
    if not content.strip(): raise HTTPException(400,"No readable text found; scanned PDFs need OCR.")
    doc_id=str(uuid.uuid4())
    try: chunks=add_document(user["id"],doc_id,filename,content)
    except RuntimeError as e: raise HTTPException(503,str(e))
    except Exception as e:
        print(f"Document indexing error: {type(e).__name__}: {e}")
        raise HTTPException(503,"Document indexing failed. Check embedding configuration.")
    with connect() as con:
        con.execute("INSERT INTO documents VALUES(?,?,?,?,?)",(doc_id,user["id"],filename,chunks,now()))
    return {"id":doc_id,"filename":filename,"chunks_indexed":chunks}

@app.get("/api/documents")
def documents(user=Depends(current_user)):
    with connect() as con:
        rows=con.execute("SELECT id,filename,chunks,created_at FROM documents WHERE user_id=? ORDER BY created_at DESC",(user["id"],)).fetchall()
    return [dict(r) for r in rows]

@app.delete("/api/documents/{document_id}")
def remove_document(document_id: str,user=Depends(current_user)):
    with connect() as con:
        row=con.execute("SELECT id FROM documents WHERE id=? AND user_id=?",(document_id,user["id"])).fetchone()
        if not row: raise HTTPException(404,"Document not found")
        delete_document(user["id"],document_id)
        con.execute("DELETE FROM documents WHERE id=? AND user_id=?",(document_id,user["id"]))
    return {"deleted":True}

@app.post("/api/feedback")
def feedback(body: FeedbackBody,user=Depends(current_user)):
    with connect() as con:
        if body.session_id:
            row=con.execute("SELECT id FROM sessions WHERE id=? AND user_id=?",(body.session_id,user["id"])).fetchone()
            if not row: raise HTTPException(404,"Conversation not found")
        con.execute("INSERT INTO feedback(user_id,session_id,rating,comment,created_at) VALUES(?,?,?,?,?)",
                    (user["id"],body.session_id,body.rating,body.comment,now()))
    return {"saved":True}

@app.get("/api/admin/stats")
def admin_stats(user=Depends(require_admin)):
    with connect() as con:
        users=con.execute("SELECT COUNT(*) n FROM users").fetchone()["n"]
        sessions=con.execute("SELECT COUNT(*) n FROM sessions").fetchone()["n"]
        messages=con.execute("SELECT COUNT(*) n FROM messages").fetchone()["n"]
        docs=con.execute("SELECT COUNT(*) n FROM documents").fetchone()["n"]
        avg=con.execute("SELECT AVG(rating) a,COUNT(*) n FROM feedback").fetchone()
        agent_rows=con.execute("SELECT agent,COUNT(*) n FROM messages WHERE role='assistant' GROUP BY agent").fetchall()
    return {"users":users,"sessions":sessions,"messages":messages,"documents":docs,
            "average_rating":round(avg["a"] or 0,2),"feedback_count":avg["n"],
            "responses_by_agent":[dict(x) for x in agent_rows]}
