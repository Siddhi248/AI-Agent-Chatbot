from pathlib import Path
from uuid import uuid4
from typing import Iterable
from app.config import get_settings

_client = None
_collection = None

def collection():
    global _client, _collection
    if _collection is None:
        import chromadb
        s = get_settings()
        Path(s.chroma_path).mkdir(parents=True, exist_ok=True)
        _client = chromadb.PersistentClient(path=s.chroma_path)
        _collection = _client.get_or_create_collection(
            name="nexus_user_knowledge",
            metadata={"hnsw:space":"cosine"}
        )
    return _collection

def embed(texts: list[str]) -> list[list[float]]:
    from app.config import get_settings
    s = get_settings()
    if not s.openai_api_key:
        raise RuntimeError("Set OPENAI_API_KEY to enable semantic RAG embeddings.")
    from openai import OpenAI
    client = OpenAI(api_key=s.openai_api_key)
    out = []
    # Keep batches modest for API reliability.
    for i in range(0, len(texts), 64):
        batch = texts[i:i+64]
        response = client.embeddings.create(model=s.openai_embedding_model, input=batch)
        out.extend([x.embedding for x in response.data])
    return out

def split_text(text: str, chunk_size=1100, overlap=160) -> list[str]:
    clean = " ".join(text.split())
    if not clean:
        return []
    chunks, start = [], 0
    while start < len(clean):
        end = min(len(clean), start + chunk_size)
        if end < len(clean):
            boundary = clean.rfind(" ", start + chunk_size//2, end)
            if boundary > start:
                end = boundary
        chunks.append(clean[start:end])
        if end >= len(clean):
            break
        start = max(end-overlap, start+1)
    return chunks

def add_document(user_id: str, document_id: str, filename: str, text: str) -> int:
    chunks = split_text(text)
    if not chunks:
        return 0
    vectors = embed(chunks)
    ids = [str(uuid4()) for _ in chunks]
    collection().upsert(
        ids=ids, documents=chunks, embeddings=vectors,
        metadatas=[{"user_id":user_id,"document_id":document_id,"filename":filename,"chunk":i}
                   for i in range(len(chunks))]
    )
    return len(chunks)

def search(user_id: str, query: str, k=5) -> list[dict]:
    s = get_settings()
    if not s.openai_api_key:
        return []
    vector = embed([query])[0]
    result = collection().query(
        query_embeddings=[vector], n_results=k,
        where={"user_id":user_id}, include=["documents","metadatas","distances"]
    )
    hits = []
    docs = (result.get("documents") or [[]])[0]
    metas = (result.get("metadatas") or [[]])[0]
    distances = (result.get("distances") or [[]])[0]
    for doc, meta, distance in zip(docs, metas, distances):
        hits.append({"text":doc,"filename":meta.get("filename","Uploaded document"),
                     "document_id":meta.get("document_id"),"distance":distance})
    return hits

def delete_document(user_id: str, document_id: str):
    collection().delete(where={"$and":[{"user_id":user_id},{"document_id":document_id}]})
