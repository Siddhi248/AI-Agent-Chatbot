from pydantic_settings import BaseSettings, SettingsConfigDict
from functools import lru_cache

class Settings(BaseSettings):
    app_name: str = "NEXUS AI 2.0"
    app_env: str = "development"
    secret_key: str = "CHANGE_ME_USE_A_LONG_RANDOM_SECRET"
    access_token_minutes: int = 60
    refresh_token_days: int = 14
    database_path: str = "./data/nexus.db"
    chroma_path: str = "./data/chroma"
    openai_api_key: str = ""
    openai_model: str = "gpt-4o-mini"
    openai_embedding_model: str = "text-embedding-3-small"
    cors_origins: str = "http://127.0.0.1:8000,http://localhost:8000"
    max_upload_mb: int = 12
    admin_email: str = "admin@example.com"
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    @property
    def origins(self):
        return [x.strip() for x in self.cors_origins.split(",") if x.strip()]

@lru_cache
def get_settings():
    return Settings()
