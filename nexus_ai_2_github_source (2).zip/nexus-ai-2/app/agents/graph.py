from typing import TypedDict, Annotated
import operator
from langgraph.graph import StateGraph, START, END
from langgraph.types import Send
from app.agents.catalog import AGENTS, route_domains, specialist_prompt
from app.rag import search
from app.config import get_settings

class AgentResult(TypedDict):
    agent: str
    answer: str
    sources: list[dict]

class GraphState(TypedDict, total=False):
    user_id: str
    message: str
    requested_agent: str
    language: str
    history: str
    selected_agents: list[str]
    agent_results: Annotated[list[AgentResult], operator.add]
    final_answer: str
    sources: list[dict]

def planner(state: GraphState):
    agents = route_domains(state["message"], state.get("requested_agent","auto"))
    return {"selected_agents":agents}

def specialist_node(state: GraphState):
    agent = state["agent"]
    message = state["message"]
    hits = search(state["user_id"], message, k=5)
    context = "\n\n".join(
        f"[Source: {h['filename']} | relevance distance: {h['distance']:.3f}]\n{h['text']}"
        for h in hits
    )
    settings = get_settings()
    if not settings.openai_api_key:
        answer = (f"{AGENTS[agent]['name']} specialist selected. Live model responses and semantic RAG "
                  f"require OPENAI_API_KEY. Your request was: {message}")
    else:
        from openai import OpenAI
        client = OpenAI(api_key=settings.openai_api_key)
        system = specialist_prompt(agent)
        if state.get("language") and state["language"] != "Auto":
            system += f" Respond in {state['language']}."
        user_content = f"Recent conversation:\n{state.get('history','')}\n\nUser request:\n{message}\n\nRetrieved user documents:\n{context or 'No matching uploaded passages.'}"
        response = client.chat.completions.create(
            model=settings.openai_model, temperature=0.25,
            messages=[{"role":"system","content":system},{"role":"user","content":user_content}]
        )
        answer = response.choices[0].message.content or "I could not produce an answer."
    return {"agent_results":[{"agent":agent,"answer":answer,"sources":hits}]}

def dispatch(state: GraphState):
    return [Send("specialist", {**state, "agent": agent}) for agent in state["selected_agents"]]

def synthesizer(state: GraphState):
    results = state.get("agent_results", [])
    if len(results) == 1:
        final = results[0]["answer"]
    elif not get_settings().openai_api_key:
        final = "\n\n---\n\n".join(f"**{AGENTS[r['agent']]['name']} Agent**\n{r['answer']}" for r in results)
    else:
        from openai import OpenAI
        client = OpenAI(api_key=get_settings().openai_api_key)
        joined = "\n\n".join(f"AGENT {r['agent']}:\n{r['answer']}" for r in results)
        response = client.chat.completions.create(
            model=get_settings().openai_model, temperature=0.2,
            messages=[
              {"role":"system","content":"Synthesize the specialist outputs into one coherent answer. Resolve overlap, preserve important caveats, do not invent facts, and identify any disagreement or missing evidence."},
              {"role":"user","content":f"Original request: {state['message']}\n\nSpecialist results:\n{joined}"}
            ]
        )
        final = response.choices[0].message.content or joined
    unique = {}
    for result in results:
        for source in result.get("sources",[]):
            unique[(source["document_id"],source["filename"],source["text"][:80])] = source
    return {"final_answer":final, "sources":list(unique.values()),
            "selected_agents":[r["agent"] for r in results]}

builder = StateGraph(GraphState)
builder.add_node("planner", planner)
builder.add_node("specialist", specialist_node)
builder.add_node("synthesizer", synthesizer)
builder.add_edge(START, "planner")
builder.add_conditional_edges("planner", dispatch, ["specialist"])
builder.add_edge("specialist", "synthesizer")
builder.add_edge("synthesizer", END)
graph = builder.compile()

def run_graph(**kwargs):
    result = graph.invoke({**kwargs, "agent_results":[]})
    return result
