AGENTS = {
 "education": {"name":"Education","icon":"🎓","description":"Tutoring, study plans, notes and quizzes"},
 "healthcare": {"name":"Healthcare","icon":"🩺","description":"General health information and wellness education"},
 "legal": {"name":"Legal","icon":"⚖️","description":"General legal information and document explanations"},
 "finance": {"name":"Finance","icon":"💰","description":"Budgeting and financial literacy"},
 "career": {"name":"Career","icon":"💼","description":"CVs, interviews and career planning"},
 "travel": {"name":"Travel","icon":"✈️","description":"Trip planning and destination guidance"},
 "agriculture": {"name":"Agriculture","icon":"🌱","description":"Crop, soil and farming information"},
 "customer_support": {"name":"Customer Support","icon":"🎧","description":"FAQs, issue triage and support workflows"}
}

KEYWORDS = {
 "education":["study","student","homework","explain","teach","exam","quiz","assignment","learn","university","course"],
 "healthcare":["health","symptom","doctor","diet","nutrition","medicine","medical","fever","pain","wellness"],
 "legal":["law","legal","lawyer","rights","court","contract","tenant","landlord","divorce","notice"],
 "finance":["money","budget","tax","loan","saving","investment","finance","expense","bank","debt"],
 "career":["career","resume","résumé","cv","interview","job","salary","linkedin","profession"],
 "travel":["travel","trip","holiday","flight","hotel","itinerary","destination","visa"],
 "agriculture":["crop","farm","farmer","soil","fertilizer","irrigation","pest","harvest","agriculture"],
 "customer_support":["refund","complaint","support","ticket","order","delivery","customer","issue"]
}

def route_domains(text: str, requested: str = "auto") -> list[str]:
    if requested != "auto":
        if requested not in AGENTS:
            raise ValueError("Unknown agent")
        return [requested]
    lowered = text.lower()
    scores = {a: sum(1 for word in words if word in lowered) for a, words in KEYWORDS.items()}
    ordered = sorted(scores, key=scores.get, reverse=True)
    if not scores[ordered[0]]:
        return ["education"]
    # Keep multiple meaningful domain matches for cross-domain requests.
    return [a for a in ordered if scores[a] > 0][:3]

def specialist_prompt(agent: str) -> str:
    base = f"""You are the {AGENTS[agent]['name']} specialist in NEXUS AI.
Give clear, useful, accurate and appropriately concise information.
Use retrieved context only when relevant. Never invent sources, citations, current facts or document contents.
If evidence is missing or uncertain, say so. Ask a concise clarifying question when essential information is missing.
Do not claim to have taken external actions."""
    if agent == "healthcare":
        base += """ You provide general health education, not diagnosis, prescriptions or emergency care.
For urgent or severe symptoms, direct the user to local emergency services or a qualified clinician."""
    elif agent == "legal":
        base += """ You provide general legal information, not legal representation or jurisdiction-specific legal advice.
Ask for jurisdiction when needed and recommend a qualified lawyer for consequential decisions or deadlines."""
    elif agent == "finance":
        base += """ You provide financial literacy and general education, not individualized investment, tax or credit advice.
Never guarantee returns."""
    elif agent == "agriculture":
        base += """ Consider local climate, crop variety, soil testing and official agricultural extension advice.
Avoid confident pesticide dosage recommendations without a verified product label and local guidance."""
    return base
