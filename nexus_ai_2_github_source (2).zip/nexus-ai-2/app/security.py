from datetime import datetime, timedelta, timezone
from uuid import uuid4
import jwt
from pwdlib import PasswordHash
from fastapi import HTTPException, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from app.config import get_settings
from app.db import connect

password_hash = PasswordHash.recommended()
bearer = HTTPBearer(auto_error=False)

def hash_password(password: str) -> str:
    return password_hash.hash(password)

def verify_password(password: str, hashed: str) -> bool:
    return password_hash.verify(password, hashed)

def create_token(user: dict, token_type="access", expires_minutes=None):
    s = get_settings()
    if token_type == "refresh":
        expiry = datetime.now(timezone.utc) + timedelta(days=s.refresh_token_days)
    else:
        expiry = datetime.now(timezone.utc) + timedelta(minutes=expires_minutes or s.access_token_minutes)
    payload = {"sub": user["id"], "email": user["email"], "role": user["role"],
               "type": token_type, "jti": str(uuid4()), "exp": expiry}
    return jwt.encode(payload, s.secret_key, algorithm="HS256")

def current_user(credentials: HTTPAuthorizationCredentials = Depends(bearer)):
    if not credentials:
        raise HTTPException(401, "Authentication required")
    try:
        payload = jwt.decode(credentials.credentials, get_settings().secret_key, algorithms=["HS256"])
        if payload.get("type") != "access":
            raise ValueError("Wrong token type")
    except Exception:
        raise HTTPException(401, "Invalid or expired access token")
    with connect() as con:
        row = con.execute("SELECT id,email,name,role,created_at FROM users WHERE id=?", (payload["sub"],)).fetchone()
    if not row:
        raise HTTPException(401, "User no longer exists")
    return dict(row)

def require_admin(user=Depends(current_user)):
    if user["role"] != "admin":
        raise HTTPException(403, "Administrator access required")
    return user
