# Security policy

Do not report vulnerabilities in public issues. Contact the repository maintainer privately with a concise reproduction and impact description.

Before public deployment, configure strong secrets, HTTPS, strict CORS, rate limiting, upload scanning, backups, audit logging and account recovery. Do not process sensitive regulated records until privacy, compliance and security reviews are complete.
