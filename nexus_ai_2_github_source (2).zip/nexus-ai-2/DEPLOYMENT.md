# Docker deployment guide

## Local Docker deployment

1. Install Docker Desktop (Windows/macOS) or Docker Engine + Compose (Linux).
2. Copy `.env.example` to `.env`.
3. Set a strong `SECRET_KEY` and your model provider API key in `.env`.
4. From the repository root run:

```bash
docker compose up --build -d
docker compose logs -f
```

5. Open http://localhost:8000. Stop with `docker compose down`.

Persistent application data is stored in the `nexus-data` Docker volume.

## Production notes

- Put the app behind a TLS-terminating reverse proxy (HTTPS).
- Restrict `CORS_ORIGINS` to exact frontend origins.
- Use managed database/vector services for multi-instance production.
- Configure backups, monitoring, rate limits, upload scanning and secrets management.
- Do not expose SQLite/Chroma data volumes publicly.
- Review first-account administrator bootstrap before public registration.
- Run dependency and container vulnerability scans before deployment.

The included Docker setup is a reproducible starting point, not a production security certification.
