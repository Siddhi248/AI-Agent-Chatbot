# Contributing to NEXUS AI

1. Fork the repository and create a feature branch.
2. Keep secrets in environment variables; never commit `.env` or API keys.
3. Add tests for new API routes, agent behavior and retrieval changes.
4. Run `python -m compileall app` before submitting a pull request.
5. Describe security, privacy and domain-safety implications in your PR.

Do not submit real personal, medical, financial or legal records as test fixtures.
